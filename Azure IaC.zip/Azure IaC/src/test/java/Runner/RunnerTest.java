package Runner;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        plugin = {"pretty", "html:target/cucumber-reports/cucumber-static-html-report.html",
                "json:target/cucumber-reports/cucumber-static.json",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
        glue = {"StepDefinitions"},
        tags = "@NSG",
                //"@Az-RouteTable",
                // "@Az-ResourceGroup",
                //"@Az-VNET",
                //"@Az-WebApps",
        //"@ACR or @NSG or @Az-KeyVault or @Az-StorageAccount or @Az-WebApps",

        dryRun = false)



public class RunnerTest {
}
