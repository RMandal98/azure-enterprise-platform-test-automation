package ReusableComponents;


import com.azure.resourcemanager.resources.models.ResourceGroup;

//public class AzRouteTable extends RouteTablesImpl {

public class AzResourceGroup {
    public final ResourceGroup azCoreMethods;


    public static void main(String[] args) {

        String strResourceGroupName = "Aby-ResourceGroup-1";
        String strRouteTableName = "routetable-2009";

        System.out.println("===========TESTS===========");

        AzResourceGroup azRouteTable = new AzResourceGroup(strResourceGroupName, strRouteTableName);
        System.out.println(AzureAuth.azureResourceManager.getCurrentSubscription().displayName());


    }


    public AzResourceGroup(String strResourceGroupName, String strRouteTableName) {
        AzureAuth azureAuth = new AzureAuth();
        azCoreMethods = azureAuth.azureResourceManager.resourceGroups().getByName("");
    }


}

