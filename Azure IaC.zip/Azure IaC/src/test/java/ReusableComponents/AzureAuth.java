package ReusableComponents;

import com.azure.core.http.policy.HttpLogDetailLevel;
import com.azure.core.management.AzureEnvironment;
import com.azure.core.management.profile.AzureProfile;
import com.azure.identity.AzureCliCredential;
import com.azure.identity.AzureCliCredentialBuilder;
import com.azure.identity.DefaultAzureCredential;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.resourcemanager.AzureResourceManager;
import com.microsoft.azure.credentials.ApplicationTokenCredentials;
import com.microsoft.azure.management.Azure;
import com.microsoft.rest.LogLevel;

public class AzureAuth {

    public static AzureResourceManager azureResourceManager;

    public AzureAuth() {
        try {


      //      DefaultAzureCredential defaultCredential = new DefaultAzureCredentialBuilder().build();
//            System.out.println(defaultCredential.toString());

            AzureCliCredential defaultCredential = new AzureCliCredentialBuilder().build();



            AzureProfile profile = new AzureProfile(AzureEnvironment.AZURE);

            azureResourceManager = AzureResourceManager.configure()
                    .withLogLevel(HttpLogDetailLevel.BASIC)
                    .authenticate(defaultCredential, profile).withSubscription("398a8a5e-41f0-4d65-bdbf-639ec53712d1");
                    //.withDefaultSubscription();


        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}
