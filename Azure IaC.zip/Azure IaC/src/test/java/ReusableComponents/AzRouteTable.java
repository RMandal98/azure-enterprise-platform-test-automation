package ReusableComponents;


import com.azure.core.http.HttpPipeline;
import com.azure.core.management.profile.AzureProfile;
import com.azure.resourcemanager.network.NetworkManager;
import com.azure.resourcemanager.network.fluent.NetworkManagementClient;
import com.azure.resourcemanager.network.implementation.RouteTablesImpl;
import com.azure.resourcemanager.network.models.Route;
import com.azure.resourcemanager.network.models.Subnet;
import com.azure.resourcemanager.resources.fluentcore.arm.Manager;

import com.azure.resourcemanager.network.models.RouteTable;
import com.sun.org.apache.xpath.internal.operations.Bool;
import org.apache.commons.lang3.ObjectUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

//public class AzRouteTable extends RouteTablesImpl {

public class AzRouteTable {
    public final RouteTable azCoreMethods;//extends Manager<NetworkManagementClient> {


    public static void main(String[] args) {

        String strResourceGroupName = "Aby-ResourceGroup-1";
        String strRouteTableName = "routetable-2009";


        System.out.println("===========TESTS===========");

        AzRouteTable azRouteTable = new AzRouteTable(strResourceGroupName, strRouteTableName);
        System.out.println(azRouteTable.azCoreMethods.name().toString());
        System.out.println(azRouteTable.azCoreMethods.resourceGroupName().toString());
        System.out.println(azRouteTable.azCoreMethods.regionName());
        System.out.println(azRouteTable.azCoreMethods.tags().toString());
        System.out.println(azRouteTable.azCoreMethods.isBgpRoutePropagationDisabled());
        System.out.println(azRouteTable.getDestinationAddressPrefixofRoute("RouteOne"));
        System.out.println(azRouteTable.getNextHopTypeofRoute("RouteOne"));
        System.out.println(azRouteTable.getNextHopIpAddressofRoute( "RouteOne"));
        System.out.println(azRouteTable.getDestinationAddressPrefixofRoute( "RouteTwo"));
        System.out.println(azRouteTable.getNextHopTypeofRoute("RouteTwo"));
        System.out.println(azRouteTable.getNextHopIpAddressofRoute( "RouteTwo"));
        System.out.println(azRouteTable.getDestinationAddressPrefixofRoute("RouteThree"));
        System.out.println(azRouteTable.getNextHopTypeofRoute( "RouteThree"));
        System.out.println(azRouteTable.getNextHopIpAddressofRoute( "RouteThree"));
        System.out.println("RouteNames : " + azRouteTable.getListofRoutesNames());

        System.out.println("=== Subnets ===");
        System.out.println(azRouteTable.getListofAssociatedSubnetNames());
        System.out.println(azRouteTable.getSubnetResourceGroup("Aby-SubNet-1"));
        System.out.println(azRouteTable.getSubnetAddressPrefix("Aby-SubNet-1"));
        System.out.println(azRouteTable.getSubnetNetworkSecurityGroupName("Aby-SubNet-1"));
        System.out.println(azRouteTable.getSubnetResourceGroup("Aby-SubNet-3"));
        System.out.println(azRouteTable.getSubnetAddressPrefix("Aby-SubNet-3"));
        System.out.println(azRouteTable.getSubnetNetworkSecurityGroupName("Aby-SubNet-3"));
        System.out.println(azRouteTable.getSubnetResourceGroup("Aby-SubNet-5"));
//      add routeTablenames
    }


    public String getDestinationAddressPrefixofRoute( String strRouteName) {
        Map<String, Route> mapRoute = azCoreMethods.routes();
        return mapRoute.get((strRouteName)).destinationAddressPrefix().toString();
    }

    public String getNextHopTypeofRoute(String strRouteName) {
        Map<String, Route> mapRoute = azCoreMethods.routes();
        return mapRoute.get((strRouteName)).nextHopType().toString();
    }

    public String getNextHopIpAddressofRoute(String strRouteName) {
        Map<String, Route> mapRoute = azCoreMethods.routes();
        try {
            return mapRoute.get((strRouteName)).nextHopIpAddress().toString();
        } catch (NullPointerException e) {
            return "-";
        }
    }

    public List getListofRoutesNames() {
        Map<String, Route> mapRoute = azCoreMethods.routes();
        List<String> listRouteNames = new ArrayList<>();
        listRouteNames.addAll(mapRoute.keySet());
        return listRouteNames;
    }

    public Boolean isPropagateGatewayRoutesEnabled() {
        return !azCoreMethods.isBgpRoutePropagationDisabled();
    }

    public String getTags() {
        return azCoreMethods.tags().toString();
    }

    public List getListofAssociatedSubnetNames() {
        List<Subnet> listSubnets = azCoreMethods.listAssociatedSubnets();
        List<String> listSubnetNames = new ArrayList<>();
        for (Subnet subnet : listSubnets) {
            listSubnetNames.add(subnet.name().toString());
        }
        return listSubnetNames;
    }

    public String getSubnetResourceGroup(String subnetName) {
        List<Subnet> listSubnets = azCoreMethods.listAssociatedSubnets();
        try {
            return listSubnets.stream().filter(e -> e.name().equals(subnetName)).collect(Collectors.toList())
                    .get(0).parent().resourceGroupName();
        } catch (IndexOutOfBoundsException e) {
            return subnetName + " not found";
        }
    }

    public String getSubnetParentVNET(String subnetName) {
        List<Subnet> listSubnets = azCoreMethods.listAssociatedSubnets();
        try {
            return listSubnets.stream().filter(e -> e.name().equals(subnetName)).collect(Collectors.toList())
                    .get(0).parent().name();
        } catch (IndexOutOfBoundsException e) {
            return subnetName + " not found";
        }
    }

//    public String getSubnetRouteTableId(String subnetName) {
//        List<Subnet> listSubnets = azCoreMethods.listAssociatedSubnets();
//        try {
//            return listSubnets.stream().filter(e -> e.name().equals(subnetName)).collect(Collectors.toList())
//                    .get(0).routeTableId();
//        } catch (IndexOutOfBoundsException e) {
//            return subnetName + " not found";
//        } catch (NullPointerException e) {
//            return "-";
//        }
//    }

    public String getSubnetAddressPrefix(String subnetName) {
        List<Subnet> listSubnets = azCoreMethods.listAssociatedSubnets();
        try {
            return listSubnets.stream().filter(e -> e.name().equals(subnetName)).collect(Collectors.toList())
                    .get(0).addressPrefix();
        } catch (IndexOutOfBoundsException e) {
            return subnetName + " not found";
        } catch (NullPointerException e) {
            return "-";
        }
    }

    public String getSubnetNetworkSecurityGroupName(String subnetName) {
        List<Subnet> listSubnets = azCoreMethods.listAssociatedSubnets();
        try {
            return listSubnets.stream().filter(e -> e.name().equals(subnetName)).collect(Collectors.toList())
                    .get(0).getNetworkSecurityGroup().name();
        } catch (IndexOutOfBoundsException e) {
            return subnetName + " not found";
        } catch (NullPointerException e) {
            return "-";
        }
    }


    public AzRouteTable(String strResourceGroupName, String strRouteTableName) {
        AzureAuth azureAuth = new AzureAuth();
        azCoreMethods = azureAuth.azureResourceManager.routeTables().getByResourceGroup(strResourceGroupName, strRouteTableName);
    }

}

