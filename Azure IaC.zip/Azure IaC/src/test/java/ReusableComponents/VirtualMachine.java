package ReusableComponents;

import java.util.Map;

public class VirtualMachine {

    public static com.azure.resourcemanager.compute.models.VirtualMachine vm;


    public VirtualMachine(String strResourceGroupName, String strVirtualMachineName) {

        vm = AzureAuth.azureResourceManager.virtualMachines().getByResourceGroup(strResourceGroupName, strVirtualMachineName);

//       System.out.println(vm.size());
//       System.out.println(vm.computerName());
//       System.out.println(vm.getPrimaryPublicIPAddress().ipAddress());
//       System.out.println(vm.getPrimaryNetworkInterface().primaryPrivateIP());
//       System.out.println(vm.isBootDiagnosticsEnabled());
//       System.out.println(vm.osDiskStorageAccountType());   //StandardSSD_LRS


    }


    public String getSize() {
        return vm.size().toString();
    }

    public String getComputerName() {
        return vm.computerName();
    }

    public String getPrimaryPublicIPAddress() {
        return vm.getPrimaryPublicIPAddress().ipAddress();
    }

    public String getPrimaryPrivateIPAddress() {
        return vm.getPrimaryNetworkInterface().primaryPrivateIP();
    }

    public String getOSName() {
        return vm.instanceView().osName();
    }

    public String getOSType() {
        return vm.osType().toString();
    }


    public String getDiskStorageType() {
        return vm.osDiskStorageAccountType().toString();
    }

    public String isBootDiagnoticsEnabled() {
        return Boolean.toString(vm.isBootDiagnosticsEnabled());
    }

    public String getOSDiskSize() {
        return Integer.toString(vm.osDiskSize());
    }

    public String getTags() {
        return ("env:" + vm.tags().get("env"));
    }

    public String getRegion() {
        return vm.regionName();
    }

    public String getAvailibility() {return vm.availabilitySetId();
    }
}
