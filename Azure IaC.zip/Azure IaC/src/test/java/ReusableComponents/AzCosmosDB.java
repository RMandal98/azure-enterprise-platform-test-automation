package ReusableComponents;

//import com.microsoft.azure.management.cosmosdb.CosmosDBAccount;
import com.azure.core.http.rest.PagedIterable;
import com.azure.resourcemanager.appservice.models.WebApp;
import com.azure.resourcemanager.appservice.models.WebDeploymentSlotBasic;
import com.azure.resourcemanager.cosmos.models.CosmosDBAccount;
import com.azure.resourcemanager.cosmos.models.Location;

import java.util.ArrayList;
import java.util.List;

public class AzCosmosDB {

    static String strResourceGroupName;
    static String strCosmosDBName;
    private CosmosDBAccount aZCosmosDB;


    public CosmosDBAccount getazCosmosDB(String strCosmosDBName, String strResourceGroupName)
    {
        AzureAuth azureAuth = new AzureAuth();
        return azureAuth.azureResourceManager.cosmosDBAccounts().getByResourceGroup(strResourceGroupName,strCosmosDBName);
    }

    public CosmosDBAccount getazCosmosDB(AzureAuth azureAuth, String strCosmosDBName, String strResourceGroupName)
    {
       // AzureAuth azureAuth = new AzureAuth();
        return azureAuth.azureResourceManager.cosmosDBAccounts().getByResourceGroup(strResourceGroupName,strCosmosDBName);
    }

    public static void main(String[] args) {

        String strResourceGroupName = "543821-IaC-CIA";
        String strCosmosDBName = "amcosmosdemo98";

        AzCosmosDB azCosmosDB = new AzCosmosDB();
        AzureAuth azureAuth = new AzureAuth();

        System.out.println("===========TESTS===========");
        System.out.println(azCosmosDB.getazCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).name());
        System.out.println(azCosmosDB.getazCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).resourceGroupName());
        System.out.println(azCosmosDB.getazCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).regionName());
        System.out.println(azCosmosDB.getazCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).tags());

        System.out.println(azCosmosDB.getazCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).kind());
//        System.out.println(azCosmosDB.getaZCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).consistencyPolicy().defaultConsistencyLevel().name());
        System.out.println(azCosmosDB.getazCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).defaultConsistencyLevel().name().toString());
        System.out.println(azCosmosDB.getazCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).multipleWriteLocationsEnabled());
        System.out.println(azCosmosDB.getListofReadableReplications(azureAuth,strCosmosDBName,strResourceGroupName));
        System.out.println(azCosmosDB.getListofWriteableReplications(azureAuth,strCosmosDBName,strResourceGroupName));
//        System.out.println(azCosmosDB.getaZCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).ipRangeFilter());
//        System.out.println(azCosmosDB.getaZCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).capabilities().get(0).name());
//        System.out.println(azCosmosDB.getaZCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).capabilities().get(0).toString());


//not absolutely sure whether required or not
       // System.out.println(azCosmosDB.getaZCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).getPrivateEndpointConnection());
       // System.out.println(azCosmosDB.getazCosmosDB(azureAuth,strCosmosDBName,strResourceGroupName).cassandraConnectorEnabled());

    }


    public List getListofReadableReplications(AzureAuth azureAuth, String strCosmosDBName, String strResourceGroupName){
        CosmosDBAccount azCosmosDB = azureAuth.azureResourceManager.cosmosDBAccounts().getByResourceGroup(strResourceGroupName,strCosmosDBName);
        List<Location> listLocations = azCosmosDB.readableReplications();
        List<String> listStrLocations = new ArrayList<>();
        for(Location location : listLocations){
            listStrLocations.add(location.locationName());
        }
        return listStrLocations;
    }

    public List getListofReadableReplications(CosmosDBAccount azCosmosDB){
        List<Location> listLocations = azCosmosDB.readableReplications();
        List<String> listStrLocations = new ArrayList<>();
        for(Location location : listLocations){
            listStrLocations.add(location.locationName());
        }
        return listStrLocations;
    }

    public List getListofWriteableReplications(AzureAuth azureAuth, String strCosmosDBName, String strResourceGroupName){
        CosmosDBAccount azCosmosDB = azureAuth.azureResourceManager.cosmosDBAccounts().getByResourceGroup(strResourceGroupName,strCosmosDBName);
        List<Location> listLocations = azCosmosDB.writableReplications();
        List<String> listStrLocations = new ArrayList<>();
        for(Location location : listLocations){
            listStrLocations.add(location.locationName());
        }
        return listStrLocations;
    }

    public List getListofWriteableReplications(CosmosDBAccount azCosmosDB){
        List<Location> listLocations = azCosmosDB.writableReplications();
        List<String> listStrLocations = new ArrayList<>();
        for(Location location : listLocations){
            listStrLocations.add(location.locationName());
        }
        return listStrLocations;
    }


}
