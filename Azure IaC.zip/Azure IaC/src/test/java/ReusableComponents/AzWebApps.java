package ReusableComponents;

import com.azure.core.http.rest.PagedIterable;
import com.azure.resourcemanager.appservice.models.DeploymentSlots;
import com.microsoft.azure.management.appservice.*;
import com.azure.resourcemanager.appservice.models.WebApp;
import com.azure.resourcemanager.appservice.models.WebDeploymentSlotBasic;

import java.util.ArrayList;
import java.util.List;

import com.microsoft.azure.management.appservice.*;

public class AzWebApps {

    static String strResourceGroupName;
    static String strAppServiceName;
    private WebApp azWebApp;

//    public  AzWebApps(String strAppServiceName, String strResourceGroupName) {
//        AzureAuth azureAuth = new AzureAuth();
//        azWebApp = azureAuth.azureResourceManager.webApps().getByResourceGroup(strResourceGroupName,strAppServiceName);
//    }


    public WebApp getAzWebAppService(String strAppServiceName, String strResourceGroupName) {
        AzureAuth azureAuth = new AzureAuth();
        return azureAuth.azureResourceManager.webApps().getByResourceGroup(strResourceGroupName, strAppServiceName);
        // Use for the Step Defn.
    }


    public List getListofDeploymentSlots(AzureAuth azureAuth, String strAppServiceName, String strResourceGroupName) {
        if (azureAuth == null) {
            azureAuth = new AzureAuth();
        }
        WebApp azWebApp = azureAuth.azureResourceManager.webApps().getByResourceGroup(strResourceGroupName, strAppServiceName);
        PagedIterable<WebDeploymentSlotBasic> listDeploymentSlots = azWebApp.deploymentSlots().list();
        List<String> listDeploymentSlotNames = new ArrayList<>();
        for (WebDeploymentSlotBasic listSlots : listDeploymentSlots) {
            listDeploymentSlotNames.add(listSlots.name());
        }
        return listDeploymentSlotNames;
    }

    public static void main(String[] args) {

        String strResourceGroupName = "543821-IaC-CIA";
        String strAppServiceName = "demowebapp2608";
//        AzWebApps azWebApps = new AzWebApps(strAppServiceName,strResourceGroupName);
        AzWebApps azWebApps = new AzWebApps();
        AzureAuth azureAuth = new AzureAuth();

        System.out.println("===========TESTS===========");
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).name());
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).resourceGroupName());
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).regionName());
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).tags());
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).getPublishingProfile().gitUrl()); //?
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).getAppSettingsAsync().toString()); //?
        System.out.println(azWebApps.getListofDeploymentSlots(azureAuth, strAppServiceName, strResourceGroupName).toString()); //? Empty due F1 Plans
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).alwaysOn());  //?
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).autoSwapSlotName()); //?
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).defaultHostname());
//        System.out.println(azWebApps.getAzWebAppService(azureAuth,strAppServiceName,strResourceGroupName).getAppSettings().toString());  //?
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).getSourceControl().repositoryUrl());// IMP! :)
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).getSourceControl().isManualIntegration());// ?


        // System.out.println(azWebApps.getAzWebAppService(azureAuth,strAppServiceName,strResourceGroupName).http20Enabled());
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).httpsOnly());
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).minTlsVersion());
        System.out.println(azWebApps.getAzWebAppService(azureAuth, strAppServiceName, strResourceGroupName).autoSwapSlotName());

    }


    public WebApp getAzWebAppService(AzureAuth azureAuth, String strAppServiceName, String strResourceGroupName) {
        return azureAuth.azureResourceManager.webApps().getByResourceGroup(strResourceGroupName, strAppServiceName);
//        return azureAuth.azureResourceManager.webApps().getByResourceGroup().manager().

    }  // only for main() Testing


}




