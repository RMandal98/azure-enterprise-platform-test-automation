package ReusableComponents;


import com.azure.core.http.rest.PagedIterable;
import com.azure.core.management.Region;
import com.azure.resourcemanager.network.models.Network;
import com.azure.resourcemanager.network.models.NetworkPeering;
import com.azure.resourcemanager.network.models.ServiceEndpointType;
import com.azure.resourcemanager.network.models.Subnet;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


public class AzVNET {
    public final Network azCoreMethods;


    public static void main(String[] args) {

        String strResourceGroupName = "Aby-ResourceGroup-1";
        String strVNETName = "Aby-VNET-1";


        System.out.println("===========TESTS===========");

        AzVNET azVNET = new AzVNET(strResourceGroupName, strVNETName);
        System.out.println(azVNET.getTags());
        System.out.println(azVNET.azCoreMethods.addressSpaces());
        System.out.println(azVNET.isAddressSpacePresent("172.18.0.0/16")); // Expect True
        System.out.println(azVNET.isAddressSpacePresent("0.18.0.0/16")); // Expect False
        System.out.println(azVNET.azCoreMethods.isDdosProtectionEnabled());//Expect False
        System.out.println(azVNET.azCoreMethods.dnsServerIPs());
        System.out.println(azVNET.getSubnetNames());
        System.out.println(azVNET.getSubnetResourceGroup("Aby-SubNet-1"));
        System.out.println(azVNET.getSubnetAddressPrefix("Aby-SubNet-1"));
        System.out.println(azVNET.getSubnetResourceGroup("Aby-SubNet-3"));
        System.out.println(azVNET.getSubnetAddressPrefix("Aby-SubNet-3"));
        System.out.println(azVNET.getSubnetNetworkSecurityGroupName("Aby-SubNet-1"));
        System.out.println(azVNET.getSubnetNetworkSecurityGroupName("Aby-SubNet-3"));
        System.out.println(azVNET.getRouteTable("Aby-SubNet-1"));
        System.out.println(azVNET.getRouteTable("Aby-SubNet-3"));
        System.out.println(azVNET.getSubnetParentVNET("Aby-SubNet-1"));



        //// Peering Values
        // This block prints the values
        System.out.println("=======================================================");
        System.out.println(">>> Peering Values - Start");
        PagedIterable<NetworkPeering> iterNetworkPeering = azVNET.azCoreMethods.peerings().list();
        for (NetworkPeering networkPeering : iterNetworkPeering) {
            System.out.println(networkPeering.name());
            System.out.println(networkPeering.getRemoteNetwork().name());
            System.out.println(networkPeering.checkAccessBetweenNetworks()); // To check if bi-directional link is present
            System.out.println(networkPeering.gatewayUse().name()); // No Gateway?
            System.out.println(networkPeering.isTrafficForwardingFromRemoteNetworkAllowed());
            System.out.println(networkPeering.remoteAddressSpaces());
            System.out.println(networkPeering.state().toString());
        }
        System.out.println(">>> Peering Values - End");
        System.out.println("=======================================================");


        System.out.println(azVNET.isServiceConnectionPresent("Aby-SubNet-1"));
        System.out.println(azVNET.isServiceConnectionPresent("Aby-SubNet-3"));
        System.out.println(azVNET.getServiceEndpointListServices("Aby-SubNet-1"));
        System.out.println(azVNET.getServiceEndpointListServices("Aby-SubNet-3"));


    }

    public String getTags() {
        return azCoreMethods.tags().toString();
    }

    public boolean isAddressSpacePresent(String strAddressSpace) {
        List<String> listAddressSpace = azCoreMethods.addressSpaces();
        return listAddressSpace.contains(strAddressSpace);
    }

    public List getSubnetNames() {
        Set<String> setSubnetNames = azCoreMethods.subnets().keySet();
        List<String> listSubnetNames = new ArrayList<>(setSubnetNames);
        return listSubnetNames;
    }

    public Boolean isSubnetPresent(String strSubnetName) {
        Map<String, Subnet> listSubnets = azCoreMethods.subnets();
        return listSubnets.containsKey(strSubnetName);
    }


    public String getSubnetResourceGroup(String strSubnetName) {  // This is sample code
        Map<String, Subnet> listSubnets = azCoreMethods.subnets();
        try {
            return listSubnets.get(strSubnetName).parent().resourceGroupName();
        } catch (IndexOutOfBoundsException e) {
            return strSubnetName + " not found";  // TODO : Test this catch exception
        }
    }

    public String getSubnetAddressPrefix(String strSubnetName) {  // This is sample code
        Map<String, Subnet> listSubnets = azCoreMethods.subnets();
        try {
            return listSubnets.get(strSubnetName).addressPrefix();
        } catch (IndexOutOfBoundsException e) {
            return strSubnetName + " not found";  // TODO : Test this catch exception
        }
    }

    public String getSubnetNetworkSecurityGroupName(String strSubnetName) {  // This is sample code
        Map<String, Subnet> listSubnets = azCoreMethods.subnets();
        if (null == listSubnets.get(strSubnetName)) {
            return strSubnetName + " not found";
        }
        try {
            return listSubnets.get(strSubnetName).getNetworkSecurityGroup().name();
        } catch (NullPointerException e) {
            return "-";
        }
    }

    public String getRouteTable(String strSubnetName) {  // This is sample code
        Map<String, Subnet> listSubnets = azCoreMethods.subnets();
        if (null == listSubnets.get(strSubnetName)) {
            return strSubnetName + " not found";
        }
        try {
            return listSubnets.get(strSubnetName).getRouteTable().name();
        } catch (IndexOutOfBoundsException e) {
            return "-";
        }
    }

    public String getSubnetParentVNET(String strSubnetName) {
        Map<String, Subnet> listSubnets = azCoreMethods.subnets();
        try {
            return listSubnets.get(strSubnetName).parent().name();
        } catch (NullPointerException e) {
            return strSubnetName + " not found";
        }
    }




    ///// Peering methods

    public String getVNETPeeringRemoteNetworkName(String strPeerName) {
        PagedIterable<NetworkPeering> iterNetworkPeering = azCoreMethods.peerings().list();
        return iterNetworkPeering.stream().filter(e -> e.name().equals(strPeerName)).collect(Collectors.toList())
                .get(0).getRemoteNetwork().name();
    }

    public String getVNETPeeringRemoteAddressSpaceList(String strPeerName) {
        PagedIterable<NetworkPeering> iterNetworkPeering = azCoreMethods.peerings().list();
        return iterNetworkPeering.stream().filter(e -> e.name().equals(strPeerName)).collect(Collectors.toList())
                .get(0).remoteAddressSpaces().toString();
    }

    public String getVNETPeeringState(String strPeerName) {
        PagedIterable<NetworkPeering> iterNetworkPeering = azCoreMethods.peerings().list();
        return iterNetworkPeering.stream().filter(e -> e.name().equals(strPeerName)).collect(Collectors.toList())
                .get(0).state().toString();
    }

    public String getVNETPeeringGatewayUse(String strPeerName) {
        PagedIterable<NetworkPeering> iterNetworkPeering = azCoreMethods.peerings().list();
        String strGatewayUse = iterNetworkPeering.stream().filter(e -> e.name().equals(strPeerName)).collect(Collectors.toList())
                .get(0).gatewayUse().name();
        if (strGatewayUse.equals("NONE"))
            return "Disabled";
        else if (strGatewayUse.equals("BY_REMOTE_NETWORK")) {
            return "Enabled"; // Confirm
        } else {
            return "";
        }
    }

    public String isTrafficForwardingFromRemoteNetworkAllowed(String strPeerName) {
        PagedIterable<NetworkPeering> iterNetworkPeering = azCoreMethods.peerings().list();
        Boolean isTrafficForwardingFromRemoteNetworkAllowed = iterNetworkPeering.stream().filter(e -> e.name().equals(strPeerName)).collect(Collectors.toList())
                .get(0).isTrafficForwardingFromRemoteNetworkAllowed();
        if (isTrafficForwardingFromRemoteNetworkAllowed)
            return "Allowed";
        else {
            return "Not Allowed";
        }
    }

    public String isCheckAccessBetweenNetworks(String strPeerName) {
        PagedIterable<NetworkPeering> iterNetworkPeering = azCoreMethods.peerings().list();
        Boolean checkAccessBetweenNetworks = iterNetworkPeering.stream().filter(e -> e.name().equals(strPeerName)).collect(Collectors.toList())
                .get(0).checkAccessBetweenNetworks();
        if (checkAccessBetweenNetworks)
            return "Allowed";
        else {
            return "Not Allowed";
        }
    }

    public Boolean isServiceConnectionPresent(String strSubnetName){
        Map<ServiceEndpointType, List<Region>> serviceEndpoints = azCoreMethods.subnets().get(strSubnetName).servicesWithAccess();
        return (serviceEndpoints.size() != 0);
    }

    public List<String> getServiceEndpointListServices(String strSubnetName){
        Set<ServiceEndpointType> setServiceEndpoint= azCoreMethods.subnets().get(strSubnetName).servicesWithAccess().keySet();
        ArrayList<ServiceEndpointType> listServiceEndpoint = new ArrayList<ServiceEndpointType>(setServiceEndpoint);
        return listServiceEndpoint.stream().map(e -> e.toString()).collect(Collectors.toList());
        // Note : this was returning a List of native ServiceEndpoint type and converted to List of String
    }


    public AzVNET(String strResourceGroupName, String strVNETName) {

        AzureAuth azureAuth = new AzureAuth();
        azCoreMethods = azureAuth.azureResourceManager.networks().getByResourceGroup(strResourceGroupName, strVNETName);
    }


}


