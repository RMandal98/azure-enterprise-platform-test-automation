package ReusableComponents;

import com.azure.resourcemanager.keyvault.models.Vault;

public class AzKeyVault {

//    public AzKeyVault(String strResourceGroupName, String strKeyVaultName) {
//        //TODO : This should be a parameterized Constructor
//    }

    public Vault getAzKeyVault(String strResourceGroupName, String strKeyVaultName) {
        AzureAuth azureAuth = new AzureAuth();
        return azureAuth.azureResourceManager.vaults().getByResourceGroup(strResourceGroupName, strKeyVaultName);
    }






    public static void main(String[] args) {

        String strResourceGroupName = "543821-IaC-CIA";
        String strKeyVaultName = "key-v-1908";
        AzKeyVault azStorageAccount = new AzKeyVault();
        AzureAuth azureAuth = new AzureAuth();

        System.out.println("===========TESTS===========");
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).name());
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).resourceGroupName());
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).regionName());
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).vaultUri());
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).sku().name());
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).softDeleteEnabled());
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).purgeProtectionEnabled());
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).tags());
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).enabledForDeployment());
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).enabledForTemplateDeployment());
        System.out.println(azStorageAccount.getKeyVault(azureAuth,strResourceGroupName,strKeyVaultName).enabledForDiskEncryption());
        System.out.println("===========TESTS===========");

    }

    public Vault getKeyVault(AzureAuth azureAuth, String strResourceGroupName, String strKeyVaultName){
//       return azureAuth.azureResourceManager.storageAccounts().getByResourceGroup(strResourceGroupName, strKeyVaultName);
        return azureAuth.azureResourceManager.vaults().getByResourceGroup(strResourceGroupName, strKeyVaultName);
    }

}