package ReusableComponents;

import com.azure.core.http.rest.PagedIterable;
import com.azure.resourcemanager.storage.fluent.models.ListContainerItemInner;
import com.azure.resourcemanager.storage.models.StorageAccount;

import java.util.ArrayList;
import java.util.List;

public class AzStorageAccount {


    static String strResourceGroupName;
    static String strStorageAccountName;
    private StorageAccount azStorageAccounts;

    public StorageAccount getAzStorageAccounts(String strStorageAccountName, String strResourceGroupName) {
        AzureAuth azureAuth = new AzureAuth();
        return azureAuth.azureResourceManager.storageAccounts().getByResourceGroup(strResourceGroupName, strStorageAccountName);
    }



    public StorageAccount getListStorageAccounts(String strResourceGroupName, String strStorageAccountName){
        return AzureAuth.azureResourceManager.storageAccounts().getByResourceGroup(strResourceGroupName,strStorageAccountName);
    }



    public List getListofContainerNames(StorageAccount azStorageAccount,String strResourceGroupName, String strStorageAccountName){
        PagedIterable<ListContainerItemInner> listContainers =
                azStorageAccount.manager().blobContainers().list(strResourceGroupName, strStorageAccountName);
        List<String> listContainerNames = new ArrayList<>();
        for(ListContainerItemInner str : listContainers){
            listContainerNames.add(str.name().toString());
        }
    return listContainerNames;
    }

    public static void main(String[] args) {

        String strResourceGroupName = "543821-IaC-CIA";
        String strStorageAccountName = "iac03082021";
        AzStorageAccount azStorageAccount = new AzStorageAccount();
        AzureAuth azureAuth = new AzureAuth();

        System.out.println(azStorageAccount.getListStorageAccounts(strResourceGroupName,strStorageAccountName).name());
//        System.out.println(azStorageAccount.getListStorageAccounts(strResourceGroupName,strStorageAccountName).
//                manager().blobContainers().list(strResourceGroupName, strStorageAccountName));

//        List<ListContainerItemInner> listContainers =
//                azureAuth.azureResourceManager.storageAccounts().getByResourceGroup(strResourceGroupName,strStorageAccountName)
//                .manager().blobContainers().list(strResourceGroupName, strStorageAccountName);
        PagedIterable<ListContainerItemInner> listContainers =
                azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName)
                .manager().blobContainers().list(strResourceGroupName, strStorageAccountName);
        List<String> listContainerNames = new ArrayList<>();
        for(ListContainerItemInner str : listContainers){
            listContainerNames.add(str.name());
        }
        System.out.println(listContainerNames.toString());

        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).accessTier());
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).skuType().name());
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).kind());

//        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).provisioningState()); //?
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).resourceGroupName());
//        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).creationTime());
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).tags());
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).regionName());
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).isBlobPublicAccessAllowed());  //?
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).endPoints());  //partially_solved

        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).isHttpsTrafficOnly());  //?
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).ipAddressesWithAccess().toString());
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).networkSubnetsWithAccess());  //solved
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).encryptionStatuses());
        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).isAccessAllowedFromAllNetworks());


        System.out.println(azStorageAccount.getStorageAccount(azureAuth, strResourceGroupName, strStorageAccountName).minimumTlsVersion());




    }


    public StorageAccount getStorageAccount(AzureAuth azureAuth, String strResourceGroupName, String strStorageAccountName){
       return azureAuth.azureResourceManager.storageAccounts().getByResourceGroup(strResourceGroupName, strStorageAccountName);
    }


}
