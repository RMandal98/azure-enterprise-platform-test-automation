package ReusableComponents;

import com.azure.core.http.rest.PagedIterable;
import com.azure.resourcemanager.appservice.models.WebApp;
import com.azure.resourcemanager.appservice.models.WebDeploymentSlotBasic;
import com.azure.resourcemanager.network.models.NetworkSecurityGroup;
import com.azure.resourcemanager.network.models.NetworkSecurityRule;
import com.azure.resourcemanager.resources.models.PolicyDefinition;
import com.azure.resourcemanager.resources.models.PolicyDefinitions;

import java.util.ArrayList;
import java.util.List;

public class AzPolicy {


    public static void main(String[] args) {
        AzPolicy azPolicy = new AzPolicy();
        AzureAuth azureAuth = new AzureAuth();
        PolicyDefinitions polDefn = azureAuth.azureResourceManager.policyDefinitions();

        System.out.println(azPolicy.getListofPolicies(polDefn));
        System.out.println(azPolicy.getListofPolicies(polDefn).size());



    }


    public List getListofPolicies(PolicyDefinitions polDefn){

        PagedIterable<PolicyDefinition> listDefinitions = polDefn.list();
        List<String> listDefinitionsNames = new ArrayList<>();
        for(PolicyDefinition listDefn : listDefinitions){
            listDefinitionsNames.add(listDefn.displayName());
        }
        return listDefinitionsNames;
    }
}

