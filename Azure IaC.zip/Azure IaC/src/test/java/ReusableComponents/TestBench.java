package ReusableComponents;

import com.azure.core.http.policy.HttpLogDetailLevel;
import com.azure.core.management.AzureEnvironment;
import com.azure.core.management.profile.AzureProfile;
import com.azure.identity.DefaultAzureCredential;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.resourcemanager.AzureResourceManager;
import com.azure.resourcemanager.compute.models.VirtualMachineDataDisk;
import com.azure.resourcemanager.compute.models.VirtualMachineUnmanagedDataDisk;
import com.azure.resourcemanager.network.models.NetworkSecurityGroup;
import com.azure.resourcemanager.network.models.NetworkSecurityRule;
import com.google.common.util.concurrent.SettableFuture;

public class TestBench {

    public static AzureResourceManager azureResourceManager;
    public static void main(String[] args){
        try {

            String SUBSCRIPTION = "333b1055-2127-4669-b427-d6cc9d782bcd";

            DefaultAzureCredential defaultCredential = new DefaultAzureCredentialBuilder().build();
            System.out.println(defaultCredential.toString());

            String strResourceGroupName = "543821-IaC-CIA";
            String strVirtualMachineName = "vmjune062021";
            AzureProfile profile = new AzureProfile(AzureEnvironment.AZURE);

            azureResourceManager = AzureResourceManager.configure()
                    .withLogLevel(HttpLogDetailLevel.BASIC)
                    .authenticate(defaultCredential, profile)
                    .withDefaultSubscription();



            com.azure.resourcemanager.compute.models.VirtualMachine vm = azureResourceManager.virtualMachines().getByResourceGroup(strResourceGroupName, strVirtualMachineName);
//
//            System.out.println(vm.computerName());
//            System.out.println(vm.availabilitySetId());

            System.out.println( vm.dataDisks().size());
            for ( VirtualMachineDataDisk dataDisk : vm.dataDisks().values()) {
                System.out.println(dataDisk.name());

            }








//            NetworkSecurityGroup nsg = azureResourceManager.networkSecurityGroups().getByResourceGroup(strResourceGroupName,"vmjune062021-nsg");
//            for (NetworkSecurityRule rule : nsg.securityRules().values()) {
////                info = printRule(rule, info);
//
//
//                System.out.println(rule.name());
//                System.out.println(rule.access());
//                System.out.println(rule.direction());
//                System.out.println(rule.sourceAddressPrefix());
//                System.out.println(rule.sourcePortRange());
//                System.out.println(rule.destinationAddressPrefix());
//                System.out.println(rule.destinationPortRange());
//                System.out.println(rule.protocol());
//                System.out.println(rule.priority());
//                rule.description();
//            }




        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}
