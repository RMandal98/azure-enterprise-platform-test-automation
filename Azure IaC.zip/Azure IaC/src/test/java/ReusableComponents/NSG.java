package ReusableComponents;

import com.azure.resourcemanager.network.models.NetworkSecurityGroup;
import com.azure.resourcemanager.network.models.NetworkSecurityRule;

import java.util.ArrayList;
import java.util.List;

public class NSG {


    public NetworkSecurityGroup getNSGObject(String strNSGName, String strResourceGroupName) {
        AzureAuth azureAuth = new AzureAuth();
        return azureAuth.azureResourceManager.networkSecurityGroups().getByResourceGroup(strResourceGroupName, strNSGName);

    }

//    public NetworkSecurityRule getNetWorkSecurityRule(NetworkSecurityGroup azNSG){
//        // EMPTY
//    }

    public String getNetworkSecurityRulesAccess(NetworkSecurityGroup azNSG, String strRuleName) {
        return azNSG.securityRules().get(strRuleName).access().toString();
    }

    public String getNetworkSecurityRulesDirection(NetworkSecurityGroup azNSG, String strRuleName) {
        return azNSG.securityRules().get(strRuleName).direction().toString();
    }

    public String getNetworkSecurityRulesSourceAddress(NetworkSecurityGroup azNSG, String strRuleName) {
        return azNSG.securityRules().get(strRuleName).sourceAddressPrefix().toString();
    }

    public String getNetworkSecurityRulesSourcePortRange(NetworkSecurityGroup azNSG, String strRuleName) {
        return azNSG.securityRules().get(strRuleName).sourcePortRange().toString();
    }

    public String getNetworkSecurityRulesDestinationAddressPrefix(NetworkSecurityGroup azNSG, String strRuleName) {
        return azNSG.securityRules().get(strRuleName).destinationAddressPrefix().toString();
    }

    public String getNetworkSecurityRulesDestinationPortRange(NetworkSecurityGroup azNSG, String strRuleName) {
        return azNSG.securityRules().get(strRuleName).destinationPortRange().toString();
    }

    public String getNetworkSecurityRulesProtocol(NetworkSecurityGroup azNSG, String strRuleName) {
        return azNSG.securityRules().get(strRuleName).protocol().toString();
    }

    public int getNetworkSecurityRulesPriority(NetworkSecurityGroup azNSG, String strRuleName) {
        return azNSG.securityRules().get(strRuleName).priority();
    }

    public boolean isExistNetworkRule(NetworkSecurityGroup azNSG, String strRuleName) {
        try{
            azNSG.securityRules().get(strRuleName).name();
            return true;
        } catch (Exception e){
            return false;
        }
    }



    public List getListofAllNetworkRuleNames(NetworkSecurityGroup azNSG){
        List<String> listNetworkRuleNames = new ArrayList<>();
        for (NetworkSecurityRule networkSecurityRule : azNSG.securityRules().values()) {
            listNetworkRuleNames.add(networkSecurityRule.name());
        }
        return listNetworkRuleNames;
    }


    public static void main(String[] args) {

        String strResourceGroupName = "543821-IaC-CIA";
        String strNSGName = "vmjune062021-nsg";


//        NSG azNsg = new NSG();
//        AzureAuth azureAuth = new AzureAuth();

        System.out.println("===========TESTS===========");
        NSG azNSG = new NSG();
        NetworkSecurityGroup NSG = azNSG.getNSGObject(strNSGName, strResourceGroupName);
        System.out.println(azNSG.getNetworkSecurityRulesPriority(NSG, "Port_80"));

    }


    public NetworkSecurityGroup getNSGObject(AzureAuth azureAuth, String strNSGName, String strResourceGroupName) {
        return azureAuth.azureResourceManager.networkSecurityGroups().getByResourceGroup(strResourceGroupName, strNSGName);

    }
}

