package ReusableComponents;

import com.azure.resourcemanager.containerregistry.models.*;


public class AzContainerRegistries {

    static String strResourceGroupName;
    static String strContainerRegistryName;
    private Registry azACR;

    public Registry getContainerRegistry(String strContainerRegistryName,String strResourceGroupName) {
        AzureAuth azureAuth = new AzureAuth();
        return azureAuth.azureResourceManager.containerRegistries().getByResourceGroup(strResourceGroupName, strContainerRegistryName);
    }

    public static void main(String[] args) {

        String strResourceGroupName = "543821-IaC-CIA";
        String strRegistryName = "demoACR2608";

        AzContainerRegistries azContainerRegistry = new AzContainerRegistries();
        AzureAuth azureAuth = new AzureAuth();

        System.out.println("===========TESTS===========");
        RegistryCredentials credentials = azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).getCredentials();
        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).name());
        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).resourceGroupName());
        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).sku().name());
        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).regionName());

        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).innerModel().networkRuleSet().toString());
        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).innerModel().policies().quarantinePolicy().status().toString());
        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).innerModel().policies().retentionPolicy().days());
        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).loginServerUrl());
        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).adminUserEnabled());
        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).getBuildSourceUploadUrl().uploadUrl());
        System.out.println(credentials.username());
        System.out.println(azContainerRegistry.getACRObject(azureAuth,strRegistryName,strResourceGroupName).storageAccountName());

//        System.out.println(credentials.accessKeys().get(AccessKeyType.PRIMARY));
//        System.out.println(credentials.accessKeys().get(AccessKeyType.SECONDARY));








    }


    public Registry getACRObject(AzureAuth azureAuth, String strRegistryName, String strResourceGroupName) {
        return azureAuth.azureResourceManager.containerRegistries().getByResourceGroup(strResourceGroupName,strRegistryName);

    }

}




