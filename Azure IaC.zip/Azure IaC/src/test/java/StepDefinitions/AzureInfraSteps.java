package StepDefinitions;

import ReusableComponents.AzureAuth;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.Assertions;

import java.util.Map;

import static org.assertj.core.api.Assertions.*;

public class AzureInfraSteps {

    static String strResourceGroupName;
    static String strVirtualMachineName;

    @Given("that I have a {string} in the {string} in Azure")
    public void that_i_have_a_in_the_in_azure(String strVirtualMachineName, String strResourceGroupName) {
        AzureAuth azure = new AzureAuth();
        System.out.println("Test");

//        strResourceGroupName = "QA-Resource-Group";
//        strVirtualMachineName = "vm-qa-june";


        this.strResourceGroupName = strResourceGroupName;
        this.strVirtualMachineName = strVirtualMachineName;


    }

    @When("I inspect the properties of the Virtual Machine")
    public void i_inspect_the_properties_of_the_virtual_machine() {


    }


    @Then("I should have the {string} as {string} for the Virtual Machine")
    public void i_should_have_the_as_for_the_virtual_machine(String strProperty, String strValue) {

//        System.out.println(strResourceGroupName);
//        System.out.println(strVirtualMachineName);
        ReusableComponents.VirtualMachine vm = new ReusableComponents.VirtualMachine(strResourceGroupName, strVirtualMachineName);


            switch (strProperty) {
                case "Name":
                    /* assertThat(strProp).isEqualTo(ReusableComponents.VirtualMachine.vm) */
                    break;
                case "Size":
                    assertThat(vm.getSize()).isEqualTo(strValue);
                    break;

                case "Public IP Address":
                    assertThat(vm.getPrimaryPublicIPAddress()).isEqualTo(strValue);
                    break;

                case "Private IP Address":
                    assertThat(vm.getPrimaryPrivateIPAddress()).isEqualTo(strValue);
                    break;

                case "OS Name":
                    assertThat(vm.getOSName()).isEqualTo(strValue);
                    break;

                case "OS Type":
                    assertThat(vm.getOSType()).isEqualTo(strValue);
                    break;
                case "OS Disk Size":
                    assertThat(vm.getOSDiskSize()).isEqualTo(strValue);
                    break;

                case "Boot Diagnostics":
                    assertThat(vm.isBootDiagnoticsEnabled()).isEqualTo(strValue);
                    break;

                case "Disk Storage Type":
                    assertThat(vm.getDiskStorageType()).isEqualTo(strValue);
                    break;

                case "Region":
                    assertThat(vm.getRegion()).isEqualTo(strValue);
                    break;

                case "Tags":
                    assertThat(vm.getTags()).isEqualTo(strValue);
                    break;
            }

    }





//    @Then("I should have following properties associated with the Virtual Machine")
//    public void i_should_have_following_properties_associated_with_the_virtual_machine(Map<String, String> mapProps) {
//
//        ReusableComponents.VirtualMachine vm = new ReusableComponents.VirtualMachine(strResourceGroupName, strVirtualMachineName);
//
//        for (String key : mapProps.keySet()) {
////            String propKey = listProps.get(i);
//
//            switch (key) {
//                case "Name":
//                    /* assertThat(strProp).isEqualTo(ReusableComponents.VirtualMachine.vm) */
//                    break;
//                case "Size":
//                    assertThat(vm.getSize()).isEqualTo(mapProps.get(key));
//                    break;
//
//                case "Public IP Address":
//                    assertThat(vm.getPrimaryPublicIPAddress()).isEqualTo(mapProps.get(key));
//                    break;
//
//                case "Private IP Address":
//                    assertThat(vm.getPrimaryPrivateIPAddress()).isEqualTo(mapProps.get(key));
//                    break;
//
//                case "OS Name":
//                    assertThat(vm.getOSName()).isEqualTo(mapProps.get(key));
//                    break;
//
//                case "OS Type":
//                    assertThat(vm.getOSType()).isEqualTo(mapProps.get(key));
//                    break;
//                case "OS Disk Size":
//                    assertThat(vm.getOSDiskSize()).isEqualTo(mapProps.get(key));
//                    break;
//
//                case "Boot Diagnostics":
//                    assertThat(vm.isBootDiagnoticsEnabled()).isEqualTo(mapProps.get(key));
//                    break;
//
//                case "Disk Storage Type":
//                    assertThat(vm.getDiskStorageType()).isEqualTo(mapProps.get(key));
//                    break;
//
//                case "Avail":
//                    assertThat(vm.getAvailibility()).isEqualTo(mapProps.get(key));
//                    break;
//            }
//        }
//    }





    ////////////////////////


    @Given("that I have a VM {string} in the {string} in Azure")
    public void that_i_have_a_vm_in_the_in_azure(String string, String string2) {

    }
    @When("I try to connect to the Virtual Machine")
    public void i_try_to_connect_to_the_virtual_machine() {

    }
    @Then("I should be able to connect into Virtual Machine")
    public void i_should_be_able_to_connect_into_virtual_machine() {
        JSch jsch = new JSch();
        Session session = null;

        try {
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            // jsch.addIdentity(sshFile, filePassword);
            session = jsch.getSession("june", "vmjune062021d062021.uksouth.cloudapp.azure.com", 22);
            session.setPassword("");
            session.setConfig(config);
            session.connect();
        } catch (Exception e) {
            Assertions.fail("SSH connection failed: " + e.getMessage());
        } finally {
            if (session != null) {
                session.disconnect();
            }
        }
    }

}
