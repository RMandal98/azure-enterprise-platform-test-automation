package StepDefinitions;

import ReusableComponents.AzWebApps;
import ReusableComponents.AzureAuth;
import com.azure.resourcemanager.appservice.models.WebApp;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.assertj.core.api.Assertions.assertThat;

public class AzWebAppSteps {

    static String strResourceGroupName;
    static String strAppServiceName;
    private WebApp azWebApp;
    private AzWebApps WebApps;

    @Given("that I have a {string} Web App in the {string} ResourceGroup in Azure")
    public void that_I_have_a_Web_App_in_the_ResourceGroup_in_Azure(String strAppServiceName,String strResourceGroupName)
    {
        this.strResourceGroupName=strResourceGroupName;
        this.strAppServiceName=strAppServiceName;
        azWebApp = new AzWebApps().getAzWebAppService(strAppServiceName,strResourceGroupName);
        WebApps = new AzWebApps();

    }

    @When("I inspect the properties of the WebApp")
    public void I_inspect_the_properties_of_the_WebApp()
    {

    }

    @Then("I should have the {string} as {string} for the WebApp")
    public void I_should_have_the_as_for_the_WebApp(String strProperty, String strValue)
    {
        switch (strProperty) {
            case "Name":
                assertThat(azWebApp.name()).isEqualTo(strValue);
                break;
            case "ResourceGroupName":
                assertThat(azWebApp.resourceGroupName()).isEqualTo(strValue);
                break;
            case "RegionName":
                assertThat(azWebApp.regionName()).isEqualTo(strValue);
                break;
            case "Tags":
                assertThat(azWebApp.tags().toString()).isEqualTo(strValue);
                break;
            case "gitUrl":
                assertThat(azWebApp.getPublishingProfile().gitUrl()).isEqualTo(strValue);
                break;
            case "alwaysOn":
                assertThat(azWebApp.alwaysOn()).isEqualTo(strValue);
                break;
            case "autoSwapSlotName":
                assertThat(azWebApp.autoSwapSlotName()).isEqualTo(strValue);
                break;
            case "defaultHostname":
                assertThat(azWebApp.defaultHostname()).isEqualTo(strValue);
                break;
            case "repositoryUrl":
                if(strValue.equals("null")){
                    assertThat(azWebApp.getSourceControl().repositoryUrl()).isNull();
                } else{
                    assertThat(azWebApp.getSourceControl().repositoryUrl()).isEqualTo(strValue);
                }
                break;
            case "isManualIntegration":
                assertThat(azWebApp.getSourceControl().isManualIntegration()).isEqualTo(Boolean.valueOf(strValue));
                break;
            case "Slots":
                assertThat(WebApps.getListofDeploymentSlots(new AzureAuth(),strAppServiceName,strResourceGroupName).toString()).isEqualTo(strValue);
                break;

        }
    }

}
