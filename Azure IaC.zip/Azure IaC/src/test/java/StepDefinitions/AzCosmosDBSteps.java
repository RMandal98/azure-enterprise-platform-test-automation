package StepDefinitions;

import ReusableComponents.AzCosmosDB;
import ReusableComponents.AzStorageAccount;
import ReusableComponents.AzureAuth;
import ReusableComponents.NSG;
import com.azure.resourcemanager.cosmos.models.CosmosDBAccount;
import com.azure.resourcemanager.network.models.NetworkSecurityGroup;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class AzCosmosDBSteps {

    static String strResourceGroupName;
    static String strCosmosDBName;
    private CosmosDBAccount azCosmosDB;
    private AzCosmosDB customazCosmosDB;


    @Given("that I have a {string} CosmosDB in the {string} ResourceGroup in Azure")
    public void that_i_have_a_cosmos_db_in_the_resource_group_in_azure(String strCosmosDBName, String strResourceGroupName) {
        this.strResourceGroupName = strResourceGroupName;
        this.strCosmosDBName = strCosmosDBName;
        azCosmosDB = new AzCosmosDB().getazCosmosDB(strCosmosDBName, strResourceGroupName);
        customazCosmosDB = new AzCosmosDB();
    }
    @When("I inspect the properties of the CosmosDB")
    public void i_inspect_the_properties_of_the_cosmos_db() {

    }
    @Then("I should have the {string} as {string} for the CosmosDB")
    public void i_should_have_the_as_for_the_cosmos_db(String strProperty, String strValue) {
        AzureAuth azureAuth = new AzureAuth(); // TODO : To refactor
        switch (strProperty) {
            case "Name":
                assertThat(azCosmosDB.name()).isEqualTo(strValue);
                break;
            case "ResourceGroup":
                assertThat(azCosmosDB.resourceGroupName()).isEqualTo(strValue);
                break;
            case "Region":
                assertThat(azCosmosDB.regionName()).isEqualTo(strValue);
                break;
            case "Kind":
                assertThat(azCosmosDB.kind()).isEqualTo(strValue);
                break;
            case "Multiple Write Locations":
                assertThat(azCosmosDB.multipleWriteLocationsEnabled()).isEqualTo(strValue);
                break;
            case "Readable Replication Location":
                assertThat(customazCosmosDB.getListofReadableReplications(azCosmosDB));  // TODO : To refactor
                break;
            case "Writeable Replication Location":
                assertThat(customazCosmosDB.getListofWriteableReplications(azCosmosDB));
                break;
            case "Consistency Level":
                assertThat(azCosmosDB.consistencyPolicy()).isEqualTo(strValue);
                break;
            case "Tags ":
                assertThat(azCosmosDB.tags()).isEqualTo(strValue);
                break;



        }
    }

}


