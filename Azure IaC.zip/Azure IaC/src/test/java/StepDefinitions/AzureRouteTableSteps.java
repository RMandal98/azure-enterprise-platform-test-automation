package StepDefinitions;

import ReusableComponents.AzRouteTable;
import ReusableComponents.NSG;
import com.azure.resourcemanager.network.models.NetworkSecurityGroup;
import io.cucumber.java.bs.A;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class AzureRouteTableSteps {

    static String strResourceGroupName;
    static String strRouteTableName;
    AzRouteTable azRouteTable;
    String strRouteName;
    String strSubnetName;


    @Given("that I have a {string} RouteTable in {string} in Azure")
    public void that_i_have_a_route_table_in_in_azure(String strRouteTableName, String strResourceGroupName) {
        azRouteTable = new AzRouteTable(strResourceGroupName, strRouteTableName);
    }

    @When("I inspect the properties of the RouteTable")
    public void i_inspect_the_properties_of_the_route_table() {

    }

    @When("I inspect the routes in the RouteTable")
    public void i_inspect_the_routes_in_the_route_table() {

    }

    @When("I inspect the subnet associations of the RouteTable")
    public void i_inspect_the_subnet_associations_of_the_route_table() {

    }

    @Then("I should have the {string} as {string} for the RouteTable")
    public void i_should_have_the_as_for_the_route_table(String strProperty, String strValue) throws Exception {
        switch (strProperty) {
            case "Name":
                assertThat(azRouteTable.azCoreMethods.name()).isEqualTo(strValue);
                break;
            case "ResourceGroup":
                assertThat(azRouteTable.azCoreMethods.resourceGroupName()).isEqualTo(strValue);
                break;
            case "Region":
                assertThat(azRouteTable.azCoreMethods.regionName()).isEqualTo(strValue);
                break;
            case "Tags":
                assertThat(azRouteTable.getTags()).isEqualTo(strValue);
                break;
            case "Propagate Gateway Routes":
                assertThat(String.valueOf(azRouteTable.isPropagateGatewayRoutesEnabled())).isEqualTo(strValue);
                break;
            default:  throw new Exception("Property not defined in tests");
        }

    }


    @Then("I should have a {string} that routes traffic from {string}")
    public void i_should_have_a_that_routes_traffic_from(String strRouteName, String strAddressPrefix) {
        this.strRouteName = strRouteName;
        assertThat(strAddressPrefix).isEqualTo(azRouteTable.getDestinationAddressPrefixofRoute(strRouteName));
    }

    @Then("Next HopType as {string} to {string}")
    public void next_hop_type_as_to(String strNextHopType, String strNextHopIPAddress) {
        this.strRouteName = strRouteName;
        assertThat(strNextHopType).isEqualTo(azRouteTable.getNextHopTypeofRoute(strRouteName));
        assertThat(strNextHopIPAddress).isEqualTo(azRouteTable.getNextHopIpAddressofRoute(strRouteName));
    }

    @Then("I should only have the following Routes configured")
    public void i_should_only_have_the_following_routes_configured(List<String> listRouteNames) {
        List actuallistRouteNames = azRouteTable.getListofRoutesNames();
        assertThat(actuallistRouteNames).containsExactlyInAnyOrder(listRouteNames.toArray());
    }



    @Then("I should only have the following subnets associated with it")
    public void i_should_only_have_the_following_subnets_associated_with_it(List<String> listSubnetNames) {
        List actuallistSubnetNames = azRouteTable.getListofAssociatedSubnetNames();
        assertThat(actuallistSubnetNames).containsExactlyInAnyOrder(listSubnetNames.toArray());
    }

    @Then("I should have a Subnet {string} from ResourceGroup {string} with Address Range {string}")
    public void i_should_have_a_subnet_from_resource_group_with_address_range(String strSubnetName, String strResourceGroup, String strAddressRange) {
        this.strSubnetName = strSubnetName;
        assertThat(azRouteTable.getSubnetResourceGroup(strSubnetName)).isEqualTo(strResourceGroup);
        assertThat(azRouteTable.getSubnetAddressPrefix(strSubnetName)).isEqualTo(strAddressRange);
    }
    @Then("belonging to the VNET {string} that has the SecurityGroup {string}")
    public void belonging_to_the_vnet_that_has_the_security_group(String strVNETName, String strNSGName) {
        assertThat(azRouteTable.getSubnetParentVNET(strSubnetName)).isEqualTo(strVNETName);
        assertThat(azRouteTable.getSubnetNetworkSecurityGroupName(strSubnetName)).isEqualTo(strNSGName);
    }


}


