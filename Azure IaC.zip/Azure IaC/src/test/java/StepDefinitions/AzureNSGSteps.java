package StepDefinitions;

import ReusableComponents.AzureAuth;
import ReusableComponents.NSG;
import com.azure.core.http.policy.HttpLogDetailLevel;
import com.azure.core.management.AzureEnvironment;
import com.azure.core.management.profile.AzureProfile;
import com.azure.identity.DefaultAzureCredential;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.resourcemanager.AzureResourceManager;
import com.azure.resourcemanager.network.models.NetworkSecurityGroup;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

public class AzureNSGSteps {

    static String strResourceGroupName;
    static String strNSGName;
    static String strRuleName;
    private NSG azNSG;
    private NetworkSecurityGroup NSG;


    @Given("that I have a {string} NSG in {string} in Azure")
    public void that_i_have_a_nsg_in_in_azure(String strNSGName, String strResourceGroupName) {
        azNSG = new NSG();
        NSG = azNSG.getNSGObject(strNSGName, strResourceGroupName);
    }

    @When("I inspect the NetworkRules of the Network Security Group")
    public void i_inspect_the_NetworkRules_of_the_network_security_group() {

    }

    @When("I inspect the properties of the Network Security Group")
    public void i_inspect_the_properties_of_the_network_security_group() {

    }

    @Then("I should have a network rule {string} that {string} {string} traffic")
    public void i_should_have_a_network_rule_that(String strCurrRuleName, String strAccess, String strDirection) {
        strRuleName = strCurrRuleName;
        assertThat(azNSG.isExistNetworkRule(NSG, strRuleName)).as("Rule exists").isEqualTo(true);
        assertThat(azNSG.getNetworkSecurityRulesAccess(NSG, strRuleName)).as("Access").isEqualTo(strAccess);
        assertThat(azNSG.getNetworkSecurityRulesDirection(NSG, strRuleName)).as("Direction").isEqualTo(strDirection);
    }

    @Then("with Source - {string} - {string}")
    public void with_source(String strSourceAddress, String strSourcePort) {
        assertThat(azNSG.getNetworkSecurityRulesSourceAddress(NSG, strRuleName)).as("Source Address").isEqualTo(strSourceAddress);
        assertThat(azNSG.getNetworkSecurityRulesSourcePortRange(NSG, strRuleName)).as("Source Port").isEqualTo(strSourcePort);
    }

    @Then("Destination - {string} - {string} on {string} with {string} priority")
    public void destination_on_with_priority(String strDestinationAddress, String strDestinationPort, String strProtocol, String strPriority) {
        assertThat(azNSG.getNetworkSecurityRulesDestinationAddressPrefix(NSG, strRuleName)).as("Destination Address").isEqualTo(strDestinationAddress);
        assertThat(azNSG.getNetworkSecurityRulesDestinationPortRange(NSG, strRuleName)).as("Destination Port").isEqualTo(strDestinationPort);
        assertThat(azNSG.getNetworkSecurityRulesProtocol(NSG, strRuleName)).as("Protocol").isEqualTo(strProtocol);
        assertThat(azNSG.getNetworkSecurityRulesPriority(NSG, strRuleName)).as("Priority").isEqualTo(Integer.valueOf(strPriority));
    }


    @Then("only the below NetworkRules should be present")
    public void only_the_below_network_rules_should_be_present(List<String> listNetworkRuleNames) {
        List actuallistNetworkRuleNames = azNSG.getListofAllNetworkRuleNames(NSG);

        assertThat(actuallistNetworkRuleNames).containsExactlyInAnyOrder(listNetworkRuleNames.toArray());
    }


    @Then("I should have the {string} as {string} for the Network Security Group")
    public void i_should_have_the_as_for_the_network_security_group(String strProperty, String strValue) {
        switch (strProperty) {
            case "Name":
                assertThat(NSG.name()).isEqualTo(strValue);
                break;
            case "ResourceGroup":
                assertThat(NSG.resourceGroupName()).isEqualTo(strValue);
                break;
            case "Region":
                assertThat(NSG.regionName()).isEqualTo(strValue);
                break;
            case "Tags":
                assertThat(NSG.tags().toString()).isEqualTo(strValue);
                break;
        }

    }
}


