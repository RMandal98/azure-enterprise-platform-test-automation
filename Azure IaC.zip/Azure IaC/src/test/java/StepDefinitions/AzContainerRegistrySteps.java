package StepDefinitions;

import ReusableComponents.AzContainerRegistries;
import ReusableComponents.AzKeyVault;
import com.azure.resourcemanager.containerregistry.models.Registry;
import com.azure.resourcemanager.containerregistry.models.RegistryCredentials;
import com.azure.resourcemanager.keyvault.models.Vault;
import com.microsoft.azure.management.batch.ContainerRegistry;
import com.sun.org.apache.xpath.internal.operations.Bool;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.assertj.core.api.Assertions.assertThat;

public class AzContainerRegistrySteps {

    static String strResourceGroupName;
    static String strContainerRegistryName;
    private Registry azACR;


    @Given("that I have a {string} ACR in {string} in Azure")
    public void that_i_have_a_acr_in_in_azure(String strContainerRegistryName, String strResourceGroupName) {
        this.strResourceGroupName = strResourceGroupName;
        this.strContainerRegistryName = strContainerRegistryName;
        azACR = new AzContainerRegistries().getContainerRegistry(strContainerRegistryName,strResourceGroupName);
    }
    @When("I inspect the properties of the Container Registry")
    public void i_inspect_the_properties_of_the_container_registry() {

    }
    @Then("I should have the {string} as {string} for the Container Registry")
    public void i_should_have_the_as_for_the_container_registry(String strProperty, String strValue) {
        switch (strProperty){  //TODO : Refactor
            case "Name" :
                assertThat(azACR.name()).isEqualTo(strValue);
                break;
            case "ResourceGroup" :
                assertThat(azACR.resourceGroupName()).isEqualTo(strValue);
                break;
            case "Region" :
                assertThat(azACR.regionName()).isEqualTo(strValue);
                break;
            case "SKU" :
                assertThat(azACR.sku().name().toString()).isEqualTo(strValue);  //TODO : Refactor
                break;
            case "Login Server URL" :
                assertThat(azACR.loginServerUrl()).isEqualTo(strValue);  //TODO : Refactor
                break;
            case "Admin User Enabled" :
                assertThat(azACR.adminUserEnabled()).isEqualTo(Boolean.valueOf(strValue));  //TODO : Refactor
                break;
            case "UserName" :
                RegistryCredentials credentials = azACR.getCredentials();
                assertThat(credentials.username()).isEqualTo(strValue);  //TODO : Refactor
                break;
//            case "Network Rules" :
//                assertThat(azACR.innerModel().networkRuleSet().toString()).isEqualTo(strValue);  //TODO : Refactor
//                break;
            case "Quarantine Policy Status" :
                assertThat(azACR.innerModel().policies().quarantinePolicy().status().toString()).isEqualTo(strValue);  //TODO : Refactor
                break;
            case "Retention Policy Days" :
                assertThat(azACR.innerModel().policies().retentionPolicy().days().toString()).isEqualTo(strValue);  //TODO : Refactor
                break;
            case "Tags" :
                assertThat(azACR.tags().toString()).isEqualTo(strValue);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + strProperty);
        }
    }


//    @Given("that I have a {string} KeyVault in the {string} ResourceGroup in Azure")
//    public void that_i_have_a_key_vault_in_the_resource_group_in_azure(String strKeyVaultName, String strResourceGroupName) {
//
//        this.strResourceGroupName = strResourceGroupName;
////        this.strKeyVaultName = strKeyVaultName;
////        vault = azureAuth.azureResourceManager.vaults().getByResourceGroup(strResourceGroupName, strKeyVaultName);
//        vault = new AzKeyVault().getAzKeyVault(strResourceGroupName,strKeyVaultName);
//
//    }
//    @When("I inspect the properties of the KeyVault")
//    public void i_inspect_the_properties_of_the_key_vault() {
//
//    }
//    @Then("I should have the {string} as {string} for the KeyVault")
//    public void i_should_have_the_as_for_the_key_vault(String strProperty, String strValue) {
//
//        switch (strProperty){
//                case "Name" :
//                    assertThat(vault.name()).isEqualTo(strValue);
//                    break;
//                case "ResourceGroup" :
//                    assertThat(vault.resourceGroupName()).isEqualTo(strValue);
//                    break;
//                case "Region" :
//                    assertThat(vault.regionName()).isEqualTo(strValue);
//                    break;
//                case "Vault URI" :
//                    assertThat(vault.vaultUri()).isEqualTo(strValue);
//                    break;
//                case "SKU" :
//                    assertThat(vault.sku().name().toString()).isEqualTo(strValue);  //TODO : Refactor
//                    break;
//                case "Soft-delete" :
//                    assertThat(vault.softDeleteEnabled()).isEqualTo(Boolean.valueOf(strValue));
//                    break;
//                case "Purge-Protection" :
//                    assertThat(vault.purgeProtectionEnabled()).isEqualTo(Boolean.valueOf(strValue));
//                    break;
//                case "Az-VM Deployment" :
//                    assertThat(vault.enabledForDeployment()).isEqualTo(Boolean.valueOf(strValue));
//                    break;
//                case "ARM Template Deployment" :
//                    assertThat(vault.enabledForTemplateDeployment()).isEqualTo(Boolean.valueOf(strValue));
//                    break;
//                case "Azure Disk Encryption for Volume encryption" :
//                    assertThat(vault.enabledForDiskEncryption()).isEqualTo(Boolean.valueOf(strValue));
//                    break;
//                case "Tags" :
//                    assertThat(vault.tags().toString()).isEqualTo(strValue);
//                    break;
//            }
//
//
//    }


}
