package StepDefinitions;

import ReusableComponents.AzVNET;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class AzVNETSteps {

    static String strResourceGroupName;
    static String strVNETName;
    String strAddressSpace;
    AzVNET azVNET;
    String strSubnetName;
    private String strPeerName;
//    String strSubnetName;


    @Given("that I have a {string} virtual network in {string} in Azure")
    public void that_i_have_a_virtual_network_in_in_azure(String strVNETName, String strResourceGroupName) {
        azVNET = new AzVNET(strResourceGroupName, strVNETName);
    }

    @When("I inspect the properties of the virtual network")
    public void i_inspect_the_properties_of_the_virtual_network() {

    }

    @When("I inspect the subnet associations of the virtual network")
    public void iInspectTheSubnetAssociationsOfTheVirtualNetwork() {
    }


    @Then("I should have the {string} as {string} for the virtual network")
    public void i_should_have_the_as_for_the_virtual_network(String strProperty, String strValue) throws Exception {
        switch (strProperty) {
            case "Name":
                assertThat(azVNET.azCoreMethods.name()).isEqualTo(strValue);
                break;
            case "ResourceGroup":
                assertThat(azVNET.azCoreMethods.resourceGroupName()).isEqualTo(strValue);
                break;
            case "Region":
                assertThat(azVNET.azCoreMethods.regionName()).isEqualTo(strValue);
                break;
            case "Address Space":
                assertThat(azVNET.azCoreMethods.addressSpaces().toString()).isEqualTo(strValue);
                break;
            case "Tags":
                assertThat(azVNET.getTags()).isEqualTo(strValue);
                break;
            case "DDoS Protection":
                assertThat(String.valueOf(azVNET.azCoreMethods.isDdosProtectionEnabled())).isEqualTo(strValue);
                break;
            case "DNS Server IP":
                assertThat(String.valueOf(azVNET.azCoreMethods.dnsServerIPs()).toString()).isEqualTo(strValue);
                break;

            default:
                throw new Exception("Property not defined in tests");
        }
    }

    @When("I inspect the subnets in the virtual network")
    public void i_inspect_the_subnets_in_the_virtual_network() {

    }

    @Then("I should have the following subnets in the virtual network")
    public void i_should_have_the_following_subnets_in_the_virtual_network(List<String> listSubnetNames) {
        List actuallistSubnetNames = azVNET.getSubnetNames();
        assertThat(actuallistSubnetNames).containsExactlyInAnyOrder(listSubnetNames.toArray());

    }

    // @Then("I should have a Subnet {string} from ResourceGroup {string} with Address Range {string} in the VNET")
    //public void i_should_have_a_subnet_from_resource_group_with_address_range_in_the_vnet(String strSubnetName, String strResourceGroup, String strAddressRange) {
    @Then("I should have a Subnet {string} in the ResourceGroup {string} with Address Range {string}")
    public void i_should_have_a_subnet_in_the_resource_group_with_address_range(String strSubnetName, String strResourceGroup, String strAddressRange) {
        this.strSubnetName = strSubnetName;
        assertThat(azVNET.getSubnetResourceGroup(strSubnetName)).isEqualTo(strResourceGroup);
        assertThat(azVNET.getSubnetAddressPrefix(strSubnetName)).isEqualTo(strAddressRange);

    }

    //@Then("should have the SecurityGroup {string} associated with it")
    //public void should_have_the_security_group_associated_with_it(String strVNETName, String strNSGName) {
    @Then("should belong to the VNET {string} that has the SecurityGroup {string}")
    public void should_belong_to_the_vnet_that_has_the_security_group(String strVNETName, String strNSGName) {
        //assertThat(azVNET.getSubnetNames(strSubnetName)).isEqualTo(strVNETName);
        assertThat(azVNET.getSubnetParentVNET(strSubnetName)).isEqualTo(strVNETName);
        assertThat(azVNET.getSubnetNetworkSecurityGroupName(strSubnetName)).isEqualTo(strNSGName);

    }

    @When("I inspect the peering of the virtual network")
    public void i_inspect_the_peering_of_the_virtual_network() {

    }
    @Then("it should be peering named {string} that peers to {string} network with AddressSpace {string}")
    public void it_should_be_peering_named_that_peers_to_network_with_address_space(String strPeerName, String strPeerVNETName, String strAddressSpace) {
        this.strPeerName = strPeerName;
        assertThat(azVNET.getVNETPeeringRemoteNetworkName(strPeerName)).isEqualTo(strPeerVNETName);
        assertThat(azVNET.getVNETPeeringRemoteAddressSpaceList(strPeerName)).isEqualTo(strAddressSpace);
    }
    @Then("should have the Peering state {string} and Gateway Transit {string}")
    public void should_have_the_peering_status_and_peering_state_and_gateway_transit(String strPeeringState, String strGatewayTransitState) {
        assertThat(azVNET.getVNETPeeringState(strPeerName)).isEqualTo(strPeeringState);
        assertThat(azVNET.getVNETPeeringGatewayUse(strPeerName)).isEqualTo(strGatewayTransitState);
    }

    @Then("it should {string} traffic forwarding from remote network")
    public void it_should_traffic_forwarding_from_remote_network(String strTrafficForwarding) {
        assertThat(azVNET.isTrafficForwardingFromRemoteNetworkAllowed(strPeerName)).isEqualToIgnoringCase(strTrafficForwarding);
    }
    @Then("{string} access between the networks")
    public void access_between_networks(String strAccessBetwenNetworks) {
        assertThat(azVNET.isCheckAccessBetweenNetworks(strPeerName)).isEqualToIgnoringCase(strAccessBetwenNetworks);
    }


    @When("I inspect the property of {string} subnet in the virtual network")
    public void i_inspect_the_property_of_subnet_in_the_virtual_network(String strSubnetName) {
       this.strSubnetName = strSubnetName;
    }
    @Then("I should not have any service endpoints to allow traffic")
    public void i_should_not_have_any_service_endpoints_to_allow_traffic() {
       assertThat(azVNET.isServiceConnectionPresent(strSubnetName)).isFalse();
    }


    @Then("I should only have the following ServiceEndpoints configured")
    public void i_should_only_have_the_following_service_endpoints_configured(List<String> listServiceEndpoints) {
        List actuallistServiceEndpoints = azVNET.getServiceEndpointListServices(strSubnetName);
        assertThat(actuallistServiceEndpoints).containsExactlyInAnyOrder(listServiceEndpoints.toArray());
    }

}











