package StepDefinitions;

import ReusableComponents.AzStorageAccount;
import ReusableComponents.AzureAuth;
import com.azure.resourcemanager.keyvault.models.Vault;
import com.azure.resourcemanager.storage.models.StorageAccount;
import com.sun.org.apache.xpath.internal.operations.Bool;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class AzStorageAccountSteps {

    static String strResourceGroupName;
    static String strStorageAccountName;
    private StorageAccount storageAccount;
    private AzStorageAccount azStorageAccount;


    @Given("that I have a {string} StorageAccount in the {string} ResourceGroup in Azure")
    public void that_i_have_a_storage_account_in_the_resource_group_in_azure(String strStorageAccountName, String strResourceGroupName) {
//        AzureAuth azureAuth = new AzureAuth();

        this.strResourceGroupName = strResourceGroupName;
        this.strStorageAccountName = strStorageAccountName;
        storageAccount = new AzStorageAccount().getAzStorageAccounts(strStorageAccountName, strResourceGroupName);
        azStorageAccount = new AzStorageAccount();
    }

    @When("I inspect the properties of the StorageAccount")
    public void i_inspect_the_properties_of_the_storage_account() {

    }

    @Then("I should have the {string} as {string} for the StorageAccount")
    public void i_should_have_the_as_for_the_storage_account(String strProperty, String strValue) {
        switch (strProperty) {
            case "Name":
                assertThat(storageAccount.name()).isEqualTo(strValue);
                break;
            case "ResourceGroup":
                assertThat(storageAccount.resourceGroupName()).isEqualTo(strValue);
                break;
            case "Region":
                assertThat(storageAccount.regionName()).isEqualTo(strValue);
                break;
            case "AccessTier":
                assertThat(storageAccount.accessTier().toString()).isEqualTo(strValue);
                break;
            case "SKU":
                assertThat(storageAccount.skuType().name().toString()).isEqualTo(strValue);
                break;
            case "Type":
                assertThat(storageAccount.kind().toString()).isEqualTo(strValue);
                break;
            case "Tags":
                assertThat(storageAccount.tags().toString()).isEqualTo(strValue);
                break;
            case "HTTPSEnabled":
                assertThat(storageAccount.isHttpsTrafficOnly()).isEqualTo(Boolean.valueOf(strValue));
                break;
            case "Blob Public Access Enabled":
                assertThat(storageAccount.isBlobPublicAccessAllowed()).isEqualTo(Boolean.valueOf(strValue));
                break;
            case "IP Addresses with Access":
                assertThat(storageAccount.ipAddressesWithAccess().toString()).isEqualTo(strValue.toString());
                break;
            case "Network Subnet with Access":
                assertThat(storageAccount.networkSubnetsWithAccess().toString()).isEqualTo(Boolean.valueOf(strValue));
                break;
            case "Encryption Status":
                assertThat(storageAccount.encryptionStatuses().toString()).isEqualTo(strValue);
                break;
            case "Access from all networks":
                assertThat(storageAccount.isAccessAllowedFromAllNetworks()).isEqualTo(Boolean.valueOf(strValue));
                break;
            case "Minimum TLS Version":
                assertThat(storageAccount.minimumTlsVersion().toString()).isEqualTo(strValue);
                break;
        }
    }



        @Then("I should have the following containers present in the Storage Account")
        public void i_should_have_the_following_containers_present_in_the_storage_account(DataTable dataTables) {
            List<String> expectedListofContainers = dataTables.asList(String.class);

            List actualListofContainers = azStorageAccount.getListofContainerNames(storageAccount,strResourceGroupName,strStorageAccountName);
//            assertThat(actualListofContainers).isEqualTo(expectedListofContainers);
            assertThat(actualListofContainers).contains(expectedListofContainers.toArray());

            System.out.println(expectedListofContainers);
            System.out.println(actualListofContainers);

        }





}
