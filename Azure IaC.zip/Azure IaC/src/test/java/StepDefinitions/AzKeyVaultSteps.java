package StepDefinitions;

import ReusableComponents.AzKeyVault;
import ReusableComponents.AzureAuth;
import com.azure.resourcemanager.keyvault.models.Vault;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.Assertions;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class AzKeyVaultSteps {

    static String strResourceGroupName;
    static String strKeyVaultName;
    private Vault vault;



    @Given("that I have a {string} KeyVault in the {string} ResourceGroup in Azure")
    public void that_i_have_a_key_vault_in_the_resource_group_in_azure(String strKeyVaultName, String strResourceGroupName) {
//        AzureAuth azureAuth = new AzureAuth();

        this.strResourceGroupName = strResourceGroupName;
        this.strKeyVaultName = strKeyVaultName;
//        vault = azureAuth.azureResourceManager.vaults().getByResourceGroup(strResourceGroupName, strKeyVaultName);
        vault = new AzKeyVault().getAzKeyVault(strResourceGroupName,strKeyVaultName);

    }
    @When("I inspect the properties of the KeyVault")
    public void i_inspect_the_properties_of_the_key_vault() {

    }
    @Then("I should have the {string} as {string} for the KeyVault")
    public void i_should_have_the_as_for_the_key_vault(String strProperty, String strValue) {

        switch (strProperty){
                case "Name" :
                    assertThat(vault.name()).isEqualTo(strValue);
                    break;
                case "ResourceGroup" :
                    assertThat(vault.resourceGroupName()).isEqualTo(strValue);
                    break;
                case "Region" :
                    assertThat(vault.regionName()).isEqualTo(strValue);
                    break;
                case "Vault URI" :
                    assertThat(vault.vaultUri()).isEqualTo(strValue);
                    break;
                case "SKU" :
                    assertThat(vault.sku().name().toString()).isEqualTo(strValue);  //TODO : Refactor
                    break;
                case "Soft-delete" :
                    assertThat(vault.softDeleteEnabled()).isEqualTo(Boolean.valueOf(strValue));
                    break;
                case "Purge-Protection" :
                    assertThat(vault.purgeProtectionEnabled()).isEqualTo(Boolean.valueOf(strValue));
                    break;
                case "Az-VM Deployment" :
                    assertThat(vault.enabledForDeployment()).isEqualTo(Boolean.valueOf(strValue));
                    break;
                case "ARM Template Deployment" :
                    assertThat(vault.enabledForTemplateDeployment()).isEqualTo(Boolean.valueOf(strValue));
                    break;
                case "Azure Disk Encryption for Volume encryption" :
                    assertThat(vault.enabledForDiskEncryption()).isEqualTo(Boolean.valueOf(strValue));
                    break;
                case "Tags" :
                    assertThat(vault.tags().toString()).isEqualTo(strValue);
                    break;
            }


    }


}
